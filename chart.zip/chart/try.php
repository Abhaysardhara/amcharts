<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>amCharts Data Loader Example</title>
  <script src="http://www.amcharts.com/lib/3/amcharts.js"></script>
  <script src="http://www.amcharts.com/lib/3/pie.js"></script>
  <!-- Export plugin includes and styles -->
    <script src="export.js"></script>
    <link  type="text/css" href="export.css" rel="stylesheet">
  <!-- include dataloader -->
  <script type="text/javascript" src="https://www.amcharts.com/lib/3/plugins/dataloader/dataloader.min.js"></script>
  <!-- select2 -->
  <script type="text/javascript" src="select2.min.js"></script>

  <!-- toastr js -->
  <script type="text/javascript" src="toastr.min.js"></script>

  <!-- jquery ui -->
  <script type="text/javascript" src="jquery-ui.min.js"></script>
  <script type="text/javascript" src="chart.js"></script>
  <script type="text/javascript" src="serial.js"></script>

  <style>
  body, html {
    height: 100%;
      padding: 0;
      margin: 0;
      overflow: hidden;
      font-size: 11px;
      font-family: Verdana;
  }
  #chartdiv {
    width: 100%;
    height: 100%;
  }
  </style>
  <script>
   var chart = AmCharts.makeChart("chartdiv", {
      "type": "pie",
      "titles": [{
        "text": "Lab Accesory",
        "size": 16
      }],
      "startDuration": 1,
      "depth3D": 10,
      "theme": "night",
      "dataLoader": {
        "url": "data.php",
        "showCurtain": false,
      },
      "titleField": "country",
      "valueField": "litres",
      "balloonText": "[[title]]<br><span style='font-size:14px'><b>[[value]]</b> ([[percents]]%)</span>",
      "innerRadius": "30%",
      "angle": 15,
      "legend": {
        "position": "right",
        "markerType": "circle"
      },
      "responsive": {
        "enabled": true
      },
      "export": {
        "enabled": true,
        "libs": {
            "path": "libs/"
          }
      }

          });
  </script>
</head>

<body>
  <div id="chartdiv"></div>
</body>

</html>