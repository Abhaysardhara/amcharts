<?php
$servername = "localhost";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$servername;dbname=lms19", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Connected successfully"; 
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

			$sql = $conn->prepare('SELECT * FROM item GROUP BY i_category');
			$sql->execute();
			$get = $sql->fetchAll();
			$count = $sql->rowCount();

			if($count > 0){

				foreach ($get as $key => $value) {
					$val[] = array('country'=>$value['i_category'],'litres'=>$value['item_rawstock']);
				}
				echo json_encode($val);

			}else{
				$val[] = array();
				echo json_encode($val);
			}
?>